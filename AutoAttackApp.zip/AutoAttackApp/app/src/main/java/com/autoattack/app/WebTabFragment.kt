package com.autoattack.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.ProgressBar
import androidx.fragment.app.Fragment

class WebTabFragment : Fragment() {
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private var accountNumber: Int = 1
    
    companion object {
        fun newInstance(accountNumber: Int): WebTabFragment {
            return WebTabFragment().apply {
                arguments = Bundle().apply { putInt("accountNumber", accountNumber) }
            }
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        accountNumber = arguments?.getInt("accountNumber") ?: 1
    }
    
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_web_tab, container, false)
        webView = view.findViewById(R.id.webView)
        progressBar = view.findViewById(R.id.progressBar)
        
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }
        }
        
        (activity as? MainActivity)?.registerWebView(accountNumber - 1, webView)
        return view
    }
}
